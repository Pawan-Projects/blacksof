(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9d126714._.css",
  "static/chunks/node_modules_next_0766a282._.js",
  "static/chunks/app_components_layout_header_header_tsx_cb4d2141._.js"
],
    source: "dynamic"
});
