(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_swiper_f0e3eb12._.js",
  "static/chunks/app_components_layout_tabs_f46a039f._.js",
  "static/chunks/_43ae3320._.css"
],
    source: "dynamic"
});
