(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/components/layout/tabs/tab2.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const tabs = [
    {
        title: 'Passenger vehicles',
        subTitle: 'Revving up innovation from interior to exterior.',
        thumbnails: [
            {
                icon: '/images/tabs/tab1/thumbnail1.png',
                video: '/images/tabs/tab1/video1.mp4'
            },
            {
                icon: '/images/tabs/tab1/thumbnail2.png',
                video: '/images/tabs/tab1/video2.mp4'
            },
            {
                icon: '/images/tabs/tab1/thumbnail3.png',
                video: '/images/tabs/tab1/video3.mp4'
            }
        ]
    },
    {
        title: 'Commercial vehicles',
        subTitle: 'Advancing engineering for heavy-duty vehicles.',
        thumbnails: [
            {
                icon: '/images/tabs/tab2/thumbnail1.png',
                video: '/images/tabs/tab2/video1.mp4'
            },
            {
                icon: '/images/tabs/tab2/thumbnail2.png',
                video: '/images/tabs/tab2/video2.mp4'
            }
        ]
    }
];
function NestedTabs() {
    _s();
    const [activeTabIndex, setActiveTabIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [activeThumbIndex, setActiveThumbIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isPlaying, setIsPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const currentTab = tabs[activeTabIndex];
    const currentThumb = currentTab.thumbnails[activeThumbIndex] || currentTab.thumbnails[0];
    const currentVideo = currentThumb?.video;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NestedTabs.useEffect": ()=>{
            if (!isPlaying) return;
            const interval = setInterval({
                "NestedTabs.useEffect.interval": ()=>{
                    setActiveThumbIndex({
                        "NestedTabs.useEffect.interval": (prev)=>(prev + 1) % currentTab.thumbnails.length
                    }["NestedTabs.useEffect.interval"]);
                }
            }["NestedTabs.useEffect.interval"], 7000);
            return ({
                "NestedTabs.useEffect": ()=>clearInterval(interval)
            })["NestedTabs.useEffect"];
        }
    }["NestedTabs.useEffect"], [
        activeTabIndex,
        isPlaying,
        currentTab.thumbnails.length
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NestedTabs.useEffect": ()=>{
            setActiveThumbIndex(0);
        }
    }["NestedTabs.useEffect"], [
        activeTabIndex
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NestedTabs.useEffect": ()=>{
            const handleScroll = {
                "NestedTabs.useEffect.handleScroll": ()=>{
                    const scrollPosition = window.scrollY;
                    const sectionHeight = window.innerHeight + 150;
                    const index = Math.floor(scrollPosition / sectionHeight);
                    if (index >= 0 && index < tabs.length) {
                        setActiveTabIndex(index);
                    }
                }
            }["NestedTabs.useEffect.handleScroll"];
            window.addEventListener('scroll', handleScroll);
            return ({
                "NestedTabs.useEffect": ()=>window.removeEventListener('scroll', handleScroll)
            })["NestedTabs.useEffect"];
        }
    }["NestedTabs.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " flex flex-col w-full justify-center items-center  bg-black text-white ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "md:text-5xl text-2xl pb-10 pt-24 text-white text-center font-light w-[70%]",
                children: [
                    "Evolving the drive with ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                        children: "360-degree "
                    }, void 0, false, {
                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                        lineNumber: 66,
                        columnNumber: 125
                    }, this),
                    "comprehensive solutions"
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                lineNumber: 66,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full hidden  md:flex md:flex-row flex-col bg-black p-4 md:px-30 sm:px-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex md:flex-col sm:flex-row md:w-[33.33%] w-screen justify-center  ",
                        children: tabs.map((tab, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setActiveTabIndex(index),
                                className: `py-10 text-start px-4 transition  ${index === activeTabIndex ? 'border-s-2 md:ps-13 ps-4 border-white text-white' : 'text-gray-600 border-s-2 ps-13 border-gray'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-3xl pt-2",
                                        children: tab.title
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-lg font-light",
                                        children: tab.subTitle
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                        lineNumber: 82,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                lineNumber: 74,
                                columnNumber: 11
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                        lineNumber: 72,
                        columnNumber: 4
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 relative w-[65%] flex flex-col justify-center items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                                src: currentVideo,
                                className: "w-full  h-[500px] object-contain",
                                autoPlay: true,
                                muted: true,
                                playsInline: true
                            }, currentVideo, false, {
                                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                lineNumber: 89,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute bottom-0 flex gap-4 items-center",
                                children: currentTab.thumbnails.map((thumb, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setActiveThumbIndex(idx),
                                        className: `w-20 h-15 opacity-40 ${idx === activeThumbIndex ? 'opacity-100' : 'border-gray-500'} rounded overflow-hidden`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: thumb.icon,
                                            className: "w-full h-full object-contain"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                            lineNumber: 109,
                                            columnNumber: 15
                                        }, this)
                                    }, idx, false, {
                                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                        lineNumber: 102,
                                        columnNumber: 13
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                lineNumber: 100,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIsPlaying(!isPlaying),
                                className: "absolute bottom-6 right-6 border border-white rounded-full w-10 h-10 flex items-center justify-center",
                                children: isPlaying ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "white",
                                    viewBox: "0 0 24 24",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "6",
                                            y: "5",
                                            width: "4",
                                            height: "14"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                            lineNumber: 121,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "14",
                                            y: "5",
                                            width: "4",
                                            height: "14"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                            lineNumber: 122,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                    lineNumber: 120,
                                    columnNumber: 13
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "white",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polygon", {
                                        points: "5,3 19,12 5,21"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                        lineNumber: 126,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                                lineNumber: 115,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                        lineNumber: 88,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/layout/tabs/tab2.tsx",
                lineNumber: 69,
                columnNumber: 8
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/layout/tabs/tab2.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(NestedTabs, "AUSqMnGKWx8t2fIYR8vuTcmL9OA=");
_c = NestedTabs;
const __TURBOPACK__default__export__ = NestedTabs;
var _c;
__turbopack_context__.k.register(_c, "NestedTabs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_components_layout_tabs_tab2_tsx_b463a7ce._.js.map